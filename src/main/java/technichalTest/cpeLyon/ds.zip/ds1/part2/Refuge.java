package technichalTest.cpeLyon.ds1.part2;

public class Refuge {

	private Animal animal;

	public void setAnimal(Animal x) {
		animal = x;
	}

	public Animal getAnimal() {
		return animal;
	}

}
