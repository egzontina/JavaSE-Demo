package technichalTest.cpeLyon.ds1.part2;

public class Chien extends Animal {
}

