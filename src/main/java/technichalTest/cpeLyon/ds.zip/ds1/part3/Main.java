package technichalTest.cpeLyon.ds1.part3;

public class Main {

	public static void main(String[] args) {

		
		Spectateur spectateur = new Spectateur(37, 80);
		Magicien.TrouverAgeEtSommeEnPoche(spectateur);
	}

}
