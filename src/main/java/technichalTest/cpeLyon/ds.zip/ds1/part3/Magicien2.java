package technichalTest.cpeLyon.ds1.part3;


public class Magicien2 {

	public static void TrouverAgeEtSommeEnPoche(Spectateur spectateur) {
		System.out.println("[Magicien]" + " un petit tour de magie...");
		
		System.out.println("[Spectateur]" + " (j'�cris le papier)");
		

	}
}

