package technichalTest.cpeLyon.ds2.part1;

public interface Cowboys extends Personnages {	
	public void tire(Brigands mechant) ;
	public void libere(Dames dame) ;
}

