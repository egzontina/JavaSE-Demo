package technichalTest.cpeLyon.ds2.part1;

public interface Dames extends Personnages {
	
	public void est_kidnappee();

	public void est_liberee(Cowboys g);
}
