package technichalTest.cpeLyon.ds2.part1;

public interface Sherifs extends Cowboys {

	public void coffre(Brigands v);

	public void recherche(Brigands b);
}
