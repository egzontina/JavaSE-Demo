package technichalTest.cpeLyon.ds2.part1;

public interface Brigands extends Personnages {

	public void emprisonne(Cowboys c);

	public void kidnappe(Dames dame);

	public int get_mise_a_prix();
}
