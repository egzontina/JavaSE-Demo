package technichalTest.cpeLyon.ds2.part1;

public interface Barmans extends Personnages {

	public void sert(Personnages h);
}
