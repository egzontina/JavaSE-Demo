package technichalTest.cpeLyon.ds2.part1;

public interface Personnages {

	public void parle(String parole);

	public void boit();

	public void presentation();

	public String que_bois_tu();

	public String quel_est_ton_nom();

}
